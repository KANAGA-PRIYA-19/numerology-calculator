<html>
<head><title>Numerology Calculator</title>
<font style="font-family: serif; font-size: 38px; padding: 15px;"><u>MEANING OF YOUR LIFE</u></font>
</head>
<style type="text/css">
	*{
		color: whitesmoke;
		text-align: center;
	}
	body{
		text-align: center;
		padding: 120px 120px;
		color: ghostwhite;
		font-style: italic;
		font-family: "papyrus",fantasy;
		font-size: 29px;
		font-display: block;
		background-image: url("p9.jpg");
		background-size: cover;
		background-repeat: repeat;
	}
	input[type="submit"]{
		font-size: 21px;
		font-family: "courier new",monospace;
		border-radius: 5px;
		border: none;
		color: black;
		background-color: lavender;
	}
	input[type="date"]{
		font-size: 20px;
		font-family: "Lucida handwriting",cursive;
		border-radius: 5px;
		color: black;
		border: none;
		background-color: lavender;
	}
	h1{
		font-family: "brush script m7", cursive;
		font-size: 32px;
	}
</style>
<body>
	<h1>Let's find out what your Life is about.</h1>
	<form name="k" method="post">
		Enter your birth date:<br><br>
		<input type="date" name="d" required><br><br>
		<input type="submit" name="s" value="Let's Find!">
	</form>
			<?php
	if($_POST){
			$date = date('d-m-Y', strtotime($_POST['d']));
			$dt=preg_replace('/-|:/', null, $date);
			echo "The date which tells about your life:\n";
			echo $date."<br>";
			$sum=0;
			for ($i=0; $i < 8; $i++) { 
				$t=$dt%10;
				$sum=$sum+$t;
				$dt=$dt/10;
			}
			$temp=$sum;
			$tot=0;
			if($temp>=10){
				for ($i=0; $i < 2 ; $i++) {
					$t1=$temp%10;
					$tot=$tot+$t1;
					$temp=$temp/10;
				}
				$sum=$tot;
				$temp1=$tot;
				$tot1=0;
				if ($temp1>=10) {
					for ($i=0; $i < 2;$i++) { 
						$t2=$temp1%10;
						$tot1=$tot1+$t2;
						$temp1=$temp1/10;
					}
				$sum=$tot1;
			}
		}
		Echo "Your Fortune Number is ";
		echo $sum;
		echo "<br><br>";
		switch ($sum) {
			case '1':
				echo "<u>Number 1</u>: Often associated with leadership, independence, and new beginnings. It represents the pioneering spirit and the energy of creation.";
				break;
			case '2':
				echo "<u>Number 2</u>: Symbolizes balance, harmony, and cooperation. It's about partnerships, diplomacy, and working together towards mutual goals.";
				break;
			case '3':
				echo "<u>Number 3</u>: Signifies creativity, self-expression, and communication. It's associated with optimism, inspiration, and the joy of living.";
				break;
			case '4':
				echo "<u>Number 4</u>: Represents stability, organization, and practicality. It embodies the qualities of hard work, determination, and building solid foundations.";
				break;
			case '5':
				echo "<u>Number 5</u>: Reflects freedom, adventure, and versatility. It's about embracing change, seeking new experiences, and living life to the fullest.";
				break;
			case '6':
				echo "<u>Number 6</u>: Symbolizes love, nurturing, and responsibility. It's associated with family, community, and harmonious relationships.";
				break;
			case '7':
				echo "<u>Number 7</u>: Signifies wisdom, intuition, and spiritual awareness. It represents a quest for knowledge, introspection, and inner growth.";
				break;
			case '8':
				echo "<u>Number 8</u>: Represents success, abundance, and achievement. It's associated with material wealth, power, and the ability to manifest goals.";
				break;
			case '9':
				echo "<u>Number 9</u>: Reflects compassion, humanitarianism, and spiritual enlightenment. It's about completion, endings, and transitioning to a higher level of consciousness.";
				break;
			default:
				echo "Please Check your Date.";
				break;
		}
	}
	?>
</body>
</html>