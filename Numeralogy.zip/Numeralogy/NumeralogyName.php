<html>
<head><title>Numerology Calculator</title>
<font style="font-family: serif; font-size: 38px; padding: 15px;"><u>WHAT YOUR NAME TELLS ABOUT YOU?</u></font>
</head>
<style type="text/css">
	*{
		color: ghostwhite;
		text-align: center;
	}
	body{
		text-align: center;
		padding: 120px 120px;
		color: ghostwhite;
		font-style: italic;
		font-family: "papyrus",fantasy;
		font-size: 29px;
		font-display: block;
		background-image: url("p9.jpg");
		background-size: cover;
		background-repeat: repeat;
	}
	input[type="submit"]{
		font-size: 21px;
		font-family: "courier new",monospace;
		border-radius: 5px;
		border: ridge;
		color: black;
		background-color: lavender;
	}
	input[type="text"]{
		font-size: 20px;
		font-family: "Lucida handwriting",cursive;
		border-radius: 5px;
		color: black;
		border: none;
		background-color: lavender;
	}
	h1{
		font-family: cursive;
		font-size: 28px;
	}
</style>
<body>
	<h1 style="font-family: serif;">Let's Find out the Meaning behind your name!!!</h1>
	<form name="k" method="post">
		Enter your birth date:<br>
		<h2 style="font-size: 14px; font-family: monospace;">***Please enter your name without your Initial.***</h2>
		<input type="text" name="t" placeholder="Enter your Name:" required><br><br>
		<input type="submit" name="s" value="Let's Find!">
	</form>
			<?php
	if($_POST){
			$x=$_POST['t'];
			echo $x." , your name tells your fortune.\n";
			$n=strlen($x);
			$tot=0;
			for ($i=0; $i < $n; $i++) { 
				if ($x[$i]=='a' || $x[$i]=='j' || $x[$i]=='s' || $x[$i]=='A' || $x[$i]=='J' || $x[$i]=='S') {
					$tot=$tot+1;
				}
				elseif ($x[$i]=='b' || $x[$i]=='k' || $x[$i]=='t' || $x[$i]=='B' || $x[$i]=='K' || $x[$i]=='T') {
					$tot=$tot+2;
				}
				elseif ($x[$i]=='c' || $x[$i]=='l' || $x[$i]=='u' || $x[$i]=='C' || $x[$i]=='L' || $x[$i]=='U') {
					$tot=$tot+3;
				}
				elseif ($x[$i]=='d' || $x[$i]=='m' || $x[$i]=='v' || $x[$i]=='D' || $x[$i]=='M' || $x[$i]=='V') {
					$tot=$tot+4;
				}
				elseif ($x[$i]=='e' || $x[$i]=='n' || $x[$i]=='w' || $x[$i]=='E' || $x[$i]=='N' || $x[$i]=='W') {
					$tot=$tot+5;
				}
				elseif ($x[$i]=='f' || $x[$i]=='o' || $x[$i]=='x' || $x[$i]=='F' || $x[$i]=='O' || $x[$i]=='X') {
					$tot=$tot+6;
				}
				elseif ($x[$i]=='g' || $x[$i]=='p' || $x[$i]=='y' || $x[$i]=='G' || $x[$i]=='P' || $x[$i]=='Y') {
					$tot=$tot+7;
				}
				elseif ($x[$i]=='h' || $x[$i]=='q' || $x[$i]=='z' || $x[$i]=='H' || $x[$i]=='Q' || $x[$i]=='Z') {
					$tot=$tot+8;
				}
				elseif ($x[$i]=='i' || $x[$i]=='r' || $x[$i]=='I' || $x[$i]=='R') {
					$tot=$tot+9;
				}
			}
			$sum=$tot;
			$temp=$sum;
			$tot=0;
			if($temp>=10){
				for ($i=0; $i < 2 ; $i++) {
					$t1=$temp%10;
					$tot=$tot+$t1;
					$temp=$temp/10;
				}
				$sum=$tot;
				$temp1=$tot;
				$tot1=0;
				if ($temp1>=10) {
					for ($i=0; $i < 2;$i++) { 
						$t2=$temp1%10;
						$tot1=$tot1+$t2;
						$temp1=$temp1/10;
					}
				$sum=$tot1;
			}
		}
		Echo "<br>Your Fortune Number is ";
		echo $sum;
		echo "<br>";
		switch ($sum) {
			case '1':
				echo "<u>Number 1</u>: Often associated with leadership, independence, and new beginnings. It represents the pioneering spirit and the energy of creation.";
				break;
			case '2':
				echo "<u>Number 2</u>: Symbolizes balance, harmony, and cooperation. It's about partnerships, diplomacy, and working together towards mutual goals.";
				break;
			case '3':
				echo "<u>Number 3</u>: Signifies creativity, self-expression, and communication. It's associated with optimism, inspiration, and the joy of living.";
				break;
			case '4':
				echo "<u>Number 4</u>: Represents stability, organization, and practicality. It embodies the qualities of hard work, determination, and building solid foundations.";
				break;
			case '5':
				echo "<u>Number 5</u>: Reflects freedom, adventure, and versatility. It's about embracing change, seeking new experiences, and living life to the fullest.";
				break;
			case '6':
				echo "<u>Number 6</u>: Symbolizes love, nurturing, and responsibility. It's associated with family, community, and harmonious relationships.";
				break;
			case '7':
				echo "<u>Number 7</u>: Signifies wisdom, intuition, and spiritual awareness. It represents a quest for knowledge, introspection, and inner growth.";
				break;
			case '8':
				echo "<u>Number 8</u>: Represents success, abundance, and achievement. It's associated with material wealth, power, and the ability to manifest goals.";
				break;
			case '9':
				echo "<u>Number 9</u>: Reflects compassion, humanitarianism, and spiritual enlightenment. It's about completion, endings, and transitioning to a higher level of consciousness.";
				break;
			default:
				echo "Please Check your Date.";
				break;
		}
		}
			?>
</body>
</html>